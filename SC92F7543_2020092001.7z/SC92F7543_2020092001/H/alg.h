#ifndef _Alg_H_
#define _Alg_H_

extern void Alg_Start(float x);
extern float Alg_Process(float x);
#endif

