#ifndef _SIGNAL_H_
#define _SIGNAL_H_


#include "H/UserHeader.h"

extern int Measure_Process(MODETYPE eMode,unsigned short adcValue);

#endif
